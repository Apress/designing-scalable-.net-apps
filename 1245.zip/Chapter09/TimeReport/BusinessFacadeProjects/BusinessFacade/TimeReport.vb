Imports System.EnterpriseServices
Imports SystemFrameworks
<ObjectPooling(Enabled:=True, MinPoolSize:=1, MaxPoolSize:=20, CreationTimeOut:=25000), JustInTimeActivation(True)> _
    Public Class TimeReport
    Inherits ServicedComponent
    'Function that returns the requested timereport.
    Public Function GetTimeReport(ByVal UserID As String, ByVal WeekNo As Integer) As SystemFrameworks.dsTimeReport
        'Our code goes here...
        Dim objTimeReport As BusinessRules.TimeReport
        Try
            If UserID.Length > 0 And WeekNo > 0 And WeekNo < 53 Then
                objTimeReport = New BusinessRules.TimeReport
                Return objTimeReport.GetTimeReport(UserID, WeekNo)
            Else
                'not valid input parameters..
                Throw New Exception("Input parameters are invalid. UserId cannot be empty and/or WeekNumber not between 1 and 52)")
            End If
        Catch e As Exception
            'throw it on the caller. .
            Throw e
        Finally
            objTimeReport.Dispose()
            objTimeReport = Nothing
        End Try

    End Function
  
    Public Function GetAllProjects(ByVal UserID As String) As SystemFrameworks.dsProjects
        'Our code goes here...
        Dim objTimeReport As BusinessRules.TimeReport
        Try
            If UserID.Length > 0 Then
                objTimeReport = New BusinessRules.TimeReport
                Return objTimeReport.GetAllProjects(UserID)
            Else
                'not valid input parameters..
                Throw New Exception("Input parameters are invalid. UserId cannot be empty and/or WeekNumber not between 1 and 52)")
            End If
        Finally
            objTimeReport.Dispose()
            objTimeReport = Nothing
        End Try
    End Function

    Public Function GetAvailableWeekReports(ByVal UserID As String) As SystemFrameworks.dsWeekReports
        'Our code goes here...
        Dim objTimeReport As BusinessRules.TimeReport
        Try
            If UserID.Length > 0 Then
                objTimeReport = New BusinessRules.TimeReport
                Return objTimeReport.GetAvailableWeekReports(UserID)
            Else
                'not valid input parameters..
                Throw New Exception("Input parameters are invalid. UserId cannot be empty and/or WeekNumber not between 1 and 52)")
            End If
        Finally
            objTimeReport.Dispose()
            objTimeReport = Nothing
        End Try
    End Function
    Public Function GetOngoingProjects(ByVal UserID As String) As SystemFrameworks.dsOngoingReports
        'Our code goes here...
        Dim objTimeReport As BusinessRules.TimeReport
        Try
            If UserID.Length > 0 Then
                objTimeReport = New BusinessRules.TimeReport
                Return objTimeReport.GetOngoingReports(UserID)
            Else
                'not valid input parameters..
                Throw New Exception("Input parameters are invalid. UserId cannot be empty and/or WeekNumber not between 1 and 52)")
            End If
        Catch e As Exception
            'throw it on the caller. .
            Throw e
        Finally
            objTimeReport.Dispose()
            objTimeReport = Nothing
        End Try

    End Function

    Public Function SaveTimeReport(ByVal UserID As String, ByVal ds As dsTimeReport)
        Dim objTimeReport As BusinessRules.TimeReport
        Try
            objTimeReport.SaveTimeReport(UserID, ds)
        Catch ex As Exception
            Throw ex
        Finally
            objTimeReport.Dispose()
            objTimeReport = Nothing
        End Try
    End Function

    Public Function SaveTimeReportAsync(ByVal UserID As String, ByVal ds As dsTimeReport)
        Dim objTimeReport As BusinessRules.ITimeReportAsync

        Try
            objTimeReport = New BusinessRules.TimeReport
            objTimeReport.SaveTimeReport(UserID, ds)
        Catch ex As Exception
            Throw ex
        Finally
            objTimeReport = Nothing
        End Try
    End Function
End Class
