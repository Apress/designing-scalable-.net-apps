Public Interface ITimeReportAsync
    Function SaveTimeReport(ByVal ds As dsTimeReport)
End Interface
