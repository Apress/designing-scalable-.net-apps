
Public Interface ITimeReportAsync
    Sub SaveTimeReport(ByVal UserID As String, ByVal ds As SystemFrameworks.dsTimeReport)
End Interface
