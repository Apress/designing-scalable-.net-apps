Example application version 1.0  Designing Scalable .NET Applications.
This project is an example application of an enterprise structure well suited for building scalable enterprise applications. 

Unzip the files to a directory.

Run the database script found in DB directory on an Sql Server. 
We included both db script and a backup of a test database.

Install the components found in the facade projects bin directory into Component Services by using the registercomponents.bat file found in the same directory.

Run the setup program for the web application found in the TimeReportWebSetup directory.

Finally start the solution file to open the projects.
